// 这个文件是自动生成、自动修改的，目的是解决引入scss时的ts报错.
// 请不要修改这个文件!
export const loading: string;

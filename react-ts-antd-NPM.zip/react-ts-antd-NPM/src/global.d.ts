declare interface Window {
    BMap: any;
    BMAP_NORMAL_MAP: any;
    BMAP_HYBRID_MAP: any;
    BMAP_ANIMATION_BOUNCE: any;
    BMap_Symbol_SHAPE_BACKWARD_OPEN_ARROW: any;
    BMapLib: any;
    initMap: () => void;
    TZSAFEBAIDUMAPCONFIG: any;
}
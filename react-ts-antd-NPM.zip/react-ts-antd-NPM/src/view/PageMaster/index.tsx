import React, { Component } from 'react';

export default class PageMaster extends Component {
    render() {
        return (
            <div>首页</div>
        )
    }
}
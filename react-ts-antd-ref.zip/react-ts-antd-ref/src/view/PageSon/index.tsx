import React, { Component } from 'react';

export default class PageSon extends Component {
    render() {
        return (
            <div>第一个子页面</div>
        )
    }
}
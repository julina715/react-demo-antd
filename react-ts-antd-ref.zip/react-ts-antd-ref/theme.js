module.exports = {
    "@layout-sider-background": "#2b2d33",
    "@layout-header-background": "#fff",
    "@layout-body-background": "#f7f7f7",
    "@layout-header-padding": '0 40px',
    "@label-color": "#757d87",
    "@input-color": "#b4c0cc",
    "@input-border-color": "#c7d0da"
}